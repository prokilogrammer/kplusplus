<?php
echo'<p>
<span class="blue">K++ is Kurukshetra Open Source Software Development Event</span><br><br>

<span class="white">Come, let us give life to software!!</span><br>

This event is a simulation of the product development life cycle in the Open Source World. Since there are no offices, neither are there employees, development takes place online. People round the world download the source tarballs, add their flavor to it and submit it back. Some one else downloads his code, add his touch to the product and re-submit along with due credits to the original author. In return what do they get..? - INSTANT PUBLICITY. Your name propagates to every nook and corner of this world. You become instantly popular. There\'s no money gambling here, there\'s no secrecy, every thing is wide open and it the individual\'s talent which makes them a hero or a zero.

</p>

<p>It is an online event and spans 35 time-crunching days where people from all over the world will be developing the software, the Open way!</p>
<p>The event consists of 3 phases.</p>
<p>At the start phase 1, participants will be given a buggy, unfinished base code along with a Problem Statement and at the start of other phases, an upgraded version of the base application will be released. This encourages new participants to start afresh even in the middle of the event.
</p>';
?>
