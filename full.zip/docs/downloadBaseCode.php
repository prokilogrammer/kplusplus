<?php
echo '<p><span class="white">Select the base code you want</span><br>
<span class="blue"><a href="baseCode/MuziK-C.tar">Base Code in C language</a></span><br><br>
<span class="blue"><a href="baseCode/MuziK-Java.tar">Base Code in Java language</a></span><br><br>
</p>';
?>
