<?php
echo '<p>
<span class="blue"> Event Co-ordinators</span><br><br>
<span class="white"> Back-End Designer</span><br> - Sanath Kumar R <br>(sanath[at]kplusplus[dot]kurukshetra[dot]org[dot]in) - +91-9841034745<br><br>
<span class="white"> Web Site Designer</span><br> - Venkatanathan V <br>(venkatanathan[at]kplusplus[dot]kurukshetra[dot]org[dot]in) - +91-9444967297<br><br>
<span class="white"> Content Manager</span><br> - Venkatakrishnan G <br>(venkatakrishnan[at]kplusplus[dot]kurukshetra[dot]org[dot]in) - +91-9790702519<br><br>
<span class="white"> Base Code Developer(C language)</span><br> - Srinath S<br> (srinath[at]kplusplus[dot]kurukshetra[dot]org[dot]in) - +91-944487708<br><br>
<span class="white"> Base Code Developer(Java)</span><br> - Naveen S<br> (naveen[at]kplusplus[dot]kurukshetra[dot]org[dot]in) - +91-9840607695<br><br>
</p>

';


?>
