<?php
echo '<p>
<span class="blue">Mail Us at:</span><br><br>
<span class="white"> kplusplus[at]kurukshetra[dot]org[dot]in</span> <br><br>
</p>';
?>
