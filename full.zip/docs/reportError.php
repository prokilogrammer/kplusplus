<?php
echo '<p>
<span class="blue">Thank you for taking time to report errors in the website. Mail us the problems to:</span><br><br>
<span class="white"> kplusplus[at]kurukshetra[dot]org[dot]in</span> <br><br>
</p>';
?>
