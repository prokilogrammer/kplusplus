<?php
echo "<p><span class='blue'>Please login before you can access this area</span></p>";

?>
