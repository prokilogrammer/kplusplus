<?php
echo '
<h1>K++</h1>
<ul id="leftmenu">
<li onClick="howToPlay()"> How To Play </li>
<li onClick="scoringSystem()"> Scoring System </li>
<li onClick="downloadBaseCode();"> Download Base Code </li>
<li onClick="displayAllScores();"> Score Card </li>
</ul>';
?>
