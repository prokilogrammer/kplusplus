<!DOCTYPE HTML PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/2000/REC-xhtml1-20000126/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml"><head>





	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<META NAME="description" CONTENT="This event is a simulation of the product development life cycle in the Open Source World. Since there are no offices, neither are there employ- ees, development takes place online. People round the world download the source tarballs, add their flavour to it and submit it back. Some one else downloads his code, add his touch to the product and re-submit along with due credits to the original author. In return what do they get..? - INSTANT PUBLICITY. Your name propagates to every nook and corner of this world. You become instantly popular. There's no money gambling here, there's no secrecy, every thing is wide open and it the individual's talent which makes them a hero or a zero.">
<META NAME="keywords" CONTENT="Kurukshetra , K++, kplusplus, Open Source, Software Development Event, Open Source Software Development, Open Source Event, Programming Contest, Bug Report, Bug, Coding Event, Linux">

<META NAME="robots" CONTENT="index,nofollow">
<META NAME="GOOGLEBOT" CONTENT="INDEX, NOFOLLOW">




<title>Kurukshetra 09 Presents...</title> 



	<link href="menu.css" rel="stylesheet" type="text/css" media="screen" />

	<link href="kstyle.css" rel="stylesheet" type="text/css" media="screen" />

<script type="text/javascript" src="script/mootools.js"></script>

<script type="text/javascript" src="script/ajaxScripts.js"></script>

<script type="text/javascript" src="script/menu.js"></script>

<script type="text/javascript" src="script/ubr_file_upload.js"></script>

	<!-- START Fx.Slide -->

	<!-- The CSS -->

  	<link rel="stylesheet" href="fx_slide.css" type="text/css" media="screen" />

	<!-- END Fx.Slide -->

  	<link rel="stylesheet" href="leftmenu.css" type="text/css" media="screen" />

 	<link rel="stylesheet" href="comments.css" type="text/css" media="screen" />

  	<link rel="stylesheet" href="tablecloth.css" type="text/css" media="screen" />

  	<script type="text/javascript" src="script/tablecloth.js"></script>

<script type="text/javascript">

var current='home';

 window.addEvent('domready', function() {

 

	if($('fancymenu'))

    FancyExample = new SlideList($E('ul', 'fancymenu'), {

          transition: Fx.Transitions.Back.easeOut, 

          duration: 800, 

          onClick: function(ev, item) { /*ev.stop();document.location.href=item.href;*/ }});



}); /*end dom-ready*/



</script>



</head>



<body onLoad="document.getElementById('spinner').style.visibility='hidden';">



     <div id="container">

		<script type="text/javascript">loadLogin()</script>

</div>

            <div id="menu">

              <div id="nav">

               <div id="fancymenu">

                  <ul>

	<li class="current menuItem"><a href="#" class="active" onClick="goHome()">-- Home --</a></li>
	<li class="current menuItem"><a href="#" class="active" onClick="problemStatement()">-- Problem Statement --</a></li>

	<li class="menuItem"><a href="http://www.kurukshetra.org.in" >-- K! Home -</a></li>

	<li class="menuItem"><a href="#" onClick="displayAllScores();" >-- Score Card --</a></li>

	<li class="menuItem"><a href="#" onClick="contactUs();" >-- Contact Us --</a></li>
	<li class="menuItem"><a href="#" onClick="aboutUs();" >-- About Us --</a></li>

                 </ul>

                 </div>

             </div>

</div>



<p class="alignright">
    <div style="height: 111px; background: transparent url('images/k_logo.png') no-repeat left center;"><img align="right" style="float: right;" src="images/logo.png"/></div><br>
</p> 

<h1>Kurukshetra Open Source Software Development Event</h1>
<div id="error" style="background-color: #ced; color: black; margin: 20px; padding-left: 10px; padding-right: 10px;">
</div>

<br>
<div id='spinner' style="height: 20px; background: transparent url('images/activity.gif') no-repeat center;"></div>

<div id="right">

<div id="NewsTicker">

  <h1>Updates</h1>

	<div id="NewsVertical">

	  <ul id="TickerVertical">

        <li>

            <span class="NewsTitle">

            <a href="#" onClick="howToPlay()">How To Play</a>

            </span>

                * Register at the above portal and get your unique login.
    * Download the base application we provide you with (consisting of both source code and an unstable executable).
    * Play, tinker with it.
    * Read and Develop the code on your own...   </li>

        <li>

         <span class="NewsTitle">

            <a href="#" onClick="scoringSystem()">Scoring System</a>

            </span>

           The Scoring System is Time based.
At every phase:
Current point counter value:
Initially, 300 points are given.
Every two hours one point gets reduced.
Next phase starts again with 300 points.

           <span class="NewsFooter"><strong>Published Dec 9</strong></span>

        </li>

       <!-- <li>

            <span class="NewsTitle">

            <a href="http://woork.blogspot.com/2008/07/navigation-bar-with-tabs-using-css.html">Navigation bar with tabs using CSS and sliding doors effect</a>

            </span>

          My friend William asked to me to design for his project a simple navigation bar with 

          tabs using CSS. I prepared for him this navbar (with status effects active, hover, link):

           <span class="NewsFooter"><strong>Published July 18</strong> - 342 comments</span>

        </li>

        <li>

            <span class="NewsTitle"><a href="http://woork.blogspot.com/2008/06/form-elements-design-using-css-and-list.html">FORM elements design using CSS and list (ul and dl)</a></span>

          In this post I would show another way to design FORM using list elements.

          In any case, if you want to use pure CSS code instead of HTML table to design your FORM 

          I think this is a good way to do it.

          <span class="NewsFooter"><strong>Published July 18</strong> - 342 comments</span>

        </li>-->

    </ul>

    </div>



</div>

</div>

		<script language="javascript" type="text/javascript">



			var Ticker = new Class({

				setOptions: function(options) {

					this.options = Object.extend({

						speed: 1500,

						delay: 5000,

						direction: 'vertical',

						onComplete: Class.empty,

						onStart: Class.empty

					}, options || {});

				},

				initialize: function(el,options){

					this.setOptions(options);

					this.el = $(el);

					this.items = this.el.getElements('li');

					var w = 0;

					var h = 0;

					if(this.options.direction.toLowerCase()=='horizontal') {

						h = this.el.getSize().size.y;

						this.items.each(function(li,index) {

							w += li.getSize().size.x;

						});

					} else {

						w = this.el.getSize().size.x;

						this.items.each(function(li,index) {

							h += li.getSize().size.y;

						});

					}

					this.el.setStyles({

						position: 'absolute',

						top: 0,

						left: 0,

						width: w,

						height: h

					});

					this.fx = new Fx.Styles(this.el,{duration:this.options.speed,onComplete:function() {

						var i = (this.current==0)?this.items.length:this.current;

						this.items[i-1].injectInside(this.el);

						this.el.setStyles({

							left:0,

							top:0

						});

					}.bind(this)});

					this.current = 0;

					this.next();

				},

				next: function() {

					this.current++;

					if (this.current >= this.items.length) this.current = 0;

					var pos = this.items[this.current];

					this.fx.start({

						top: -pos.offsetTop,

						left: -pos.offsetLeft

					});

					this.next.bind(this).delay(this.options.delay+this.options.speed);

				}

			});



			var vert = new Ticker('TickerVertical',{speed:2500,delay:3000,direction:'vertical'});

		</script>

<div id="left">

<script type="text/javascript"> loadLeftPannel()</script>

</div>



<div id="content">

<p>

<span class="blue">K++ is Kurukshetra Open Source Software Development Event</span><br><br>



<span class="white">Come, let us give life to software!!</span><br>



This event is a simulation of the product development life cycle in the

Open Source World. Since there are no offices, neither are there employ-

ees, development takes place online. People round the world download the

source tarballs, add their avor to it and submit it back. Some one else

downloads his code, add his touch to the product and re-submit along with

due credits to the original author. In return what do they get..? - INSTANT

PUBLICITY. Your name propagates to every nook and corner of this world.

You become instantly popular. There's no money gambling here, there's no

secrecy, every thing is wide open and it the individual's talent which makes

them a hero or a zero.</p>



<p>It is an online event and spans 40 time-crunching days where people from all over the world will be developing the software, the Open way!</p>

<p>The event consists of 3 phases.</p>

<p>At the start phase 1, participants will be given a buggy, unfinished base code along with a Problem Statement and at the start of other phases, an upgraded version of the base application will be released. This encourages new participants to start afresh even in the middle of the event.

</p>

</div>

<br>

</body>

</html>
