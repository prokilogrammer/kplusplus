<?php
echo "You are not permitted to view this area. Please visit <a href='http://kplusplus.kurukshetra.org.in'>Kplusplus</a>";
?>
