There is no Bug Patch... :P 
#include<nothing.h>
