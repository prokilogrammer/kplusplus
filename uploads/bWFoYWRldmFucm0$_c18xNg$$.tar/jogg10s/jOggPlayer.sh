#!/bin/sh
#
# the settings in this script assume you are running Java 1.3
# If not you will have to upadate the classpaths to include JMF and/or 
# Swing as needed.



if [ -z "$JAVA_HOME" ]
then
  echo "\nError: The JAVA_HOME environment variable is not set. Exiting script.\n"
  exit 1
fi

JOGG_PLAYER_HOME=/home/gutwin/usr/jOgg
CLASSNAME=ca.bc.webarts.jOggPlayer

# start the player
echo "\nStarting the Java jOggPlayer..."
java -cp "${JOGG_PLAYER_HOME}/jOggPlayer.jar:${JAVA_HOME}/jre/lib/rt.jar:.:${CLASSPATH}:" $CLASSNAME $1 $2 $3 $4 $5 $6 $7 $8 $9
